export interface AddProductModel {
    id: number,
    productName: string,
    author: string,
    productPrice: number
}
